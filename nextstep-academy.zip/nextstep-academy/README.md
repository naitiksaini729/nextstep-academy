# NextStep Academy - Milestone 1

A responsive local-business website for a realistic Jaipur coaching academy.

## Pages
- Home
- Courses
- Gallery
- Contact

## Technologies
- HTML5
- CSS3
- Tailwind CSS CDN

## JavaScript
JavaScript is intentionally not used in this project.

## Milestone requirements covered
- Hero section
- Testimonials
- CSS Grid course cards
- Pricing
- Flexbox Why Choose Us section
- Responsive gallery
- Accessible contact form
- Business hours
- CTA buttons
- Address and Google Maps embed
